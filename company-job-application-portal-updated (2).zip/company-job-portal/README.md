# Company Job Application Portal

A responsive, full-stack company portal for job applications and business deal proposals. Applicants can apply for a job or submit a partnership, investment, supplier, distribution, joint venture or acquisition proposal. They can later check the company's status/reply using their Submission ID and email. The private admin dashboard lists all submissions and lets the admin update their status and send a private reply.

## Features

- Public job application form
- Public Business Deals proposal form (partnership, investment, supplier, distribution, joint venture, acquisition or other)
- Unique Submission ID after either form is submitted
- Applicant/proposer status and reply tracking using Submission ID + email
- Admin login and private dashboard for both submission types
- Admin inbox filters for All submissions, Jobs and Business Deals
- Search by name, email, phone, position, business name, deal type or ID
- Job status options: Received, Under Review, Shortlisted, Interview, Accepted, Rejected
- Business status options: Received, Under Review, Meeting, Negotiating, Accepted, Rejected
- Admin replies are visible only to the matching applicant/proposer on the tracking page
- Existing job-only SQLite databases are upgraded automatically with the new submission type fields
- SQLite database: application records persist after server restarts
- Server-side admin authentication, rate limits, secure session cookies and basic security headers

## Run on your computer

1. Install Node.js 20 or newer.
2. Open a terminal in this project folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env`.
5. Run the site:

   ```bash
   npm start
   ```

6. Open `http://localhost:3000` in your browser.

The initial admin password is `223311` (as requested). Open **Admin** in the website to sign in. Job applications and Business Deals use the same admin dashboard. Use **All submissions**, **Jobs** and **Business Deals** filters to organize the inbox.

## Before publishing online

- Change `ADMIN_PASSWORD` to a long, unique password in your hosting environment.
- Set `SESSION_SECRET` to a random secret of at least 32 characters.
- Set `NODE_ENV=production`.
- Use HTTPS.
- Configure a persistent disk and set `DB_PATH` to a file on that disk. Without persistent storage, SQLite data may be lost when a hosting provider replaces the server instance.
- Back up the SQLite database regularly. Applicant information is personal data; restrict staff access and publish an appropriate privacy notice.
- The session store is SQLite-backed in this project. For a multi-instance/high-traffic deployment, use a managed database and a shared production session store.

## Deployment notes

This is a Node.js/Express application, not a static-only HTML page. Deploy it to a Node-capable host (for example, a service that supports Node web services and persistent disks). Set the environment variables listed in `.env.example`, run `npm install`, and use `npm start` as the start command.

## Customization

Edit `public/index.html` to replace `YOUR COMPANY` / `Your Company` and update the careers and Business Deals copy. Colors and layout are in `public/style.css`.
