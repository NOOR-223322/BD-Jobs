const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
const JOB_STATUS_OPTIONS = ['Received', 'Under Review', 'Shortlisted', 'Interview', 'Accepted', 'Rejected'];
const BUSINESS_STATUS_OPTIONS = ['Received', 'Under Review', 'Meeting', 'Negotiating', 'Accepted', 'Rejected'];
let cachedApplications = [];
let activeFilter = 'all';

function showNotice(element, message, type = 'error') {
  element.textContent = message;
  element.className = `notice ${type === 'success' ? 'success' : ''}`;
}
function clearNotice(element) {
  element.textContent = '';
  element.className = 'notice';
}
function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  window.setTimeout(() => toast.classList.remove('show'), 2600);
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
  return data;
}
function setView(viewName) {
  $$('.view').forEach(view => view.classList.toggle('active', view.id === `view-${viewName}`));
  $$('.nav-link').forEach(button => button.classList.toggle('active', button.dataset.view === viewName));
  if (viewName === 'admin') checkAdminSession();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
$$('[data-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.view)));
$$('[data-go-apply]').forEach(link => link.addEventListener('click', event => {
  event.preventDefault();
  setView('home');
  window.setTimeout(() => $('#apply').scrollIntoView({ behavior: 'smooth' }), 40);
}));
$$('.nav-link').forEach(button => button.addEventListener('click', () => {
  const next = button.dataset.view;
  if (next === 'home') history.replaceState(null, '', '#home');
  else history.replaceState(null, '', `#${next}`);
}));

$('#apply-form').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = $('button[type="submit"]', form);
  const notice = $('#apply-message');
  clearNotice(notice);
  button.disabled = true;
  button.textContent = 'Submitting...';
  const body = Object.fromEntries(new FormData(form).entries());
  try {
    const result = await api('/api/applications', { method: 'POST', body: JSON.stringify(body) });
    form.reset();
    showNotice(notice, `Job application submitted! Your Submission ID is ${result.id}. Save this ID and use it with your email on the Track submission page.`, 'success');
    notice.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } catch (error) {
    showNotice(notice, error.message);
  } finally {
    button.disabled = false;
    button.innerHTML = 'Submit application <span>↗</span>';
  }
});

$('#business-form').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = $('button[type="submit"]', form);
  const notice = $('#business-message');
  clearNotice(notice);
  button.disabled = true;
  button.textContent = 'Submitting proposal...';
  const body = Object.fromEntries(new FormData(form).entries());
  try {
    const result = await api('/api/business-deals', { method: 'POST', body: JSON.stringify(body) });
    form.reset();
    showNotice(notice, `Business proposal submitted! Your Submission ID is ${result.id}. Save this ID and use it with your email on the Track submission page.`, 'success');
    notice.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } catch (error) {
    showNotice(notice, error.message);
  } finally {
    button.disabled = false;
    button.innerHTML = 'Submit business proposal <span>↗</span>';
  }
});

$('#track-form').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = $('button[type="submit"]', form);
  const notice = $('#track-message');
  const resultBox = $('#track-result');
  resultBox.hidden = true;
  clearNotice(notice);
  button.disabled = true;
  button.textContent = 'Checking...';
  const body = Object.fromEntries(new FormData(form).entries());
  try {
    const result = await api('/api/track', { method: 'POST', body: JSON.stringify(body) });
    renderTrackResult(result.application);
    resultBox.hidden = false;
  } catch (error) {
    showNotice(notice, error.message);
  } finally {
    button.disabled = false;
    button.innerHTML = 'Check submission <span>→</span>';
  }
});

function renderTrackResult(application) {
  const box = $('#track-result');
  box.replaceChildren();
  const top = document.createElement('div');
  top.className = 'result-top';
  const titleWrap = document.createElement('div');
  const id = document.createElement('div');
  id.className = 'result-id';
  id.textContent = `${application.type === 'business' ? 'BUSINESS DEAL' : 'JOB APPLICATION'} · ${application.id}`;
  const title = document.createElement('h3');
  title.textContent = application.name;
  const position = document.createElement('div');
  position.className = 'application-meta';
  position.textContent = application.type === 'business'
    ? `${application.dealType || 'Business proposal'} · ${application.businessName || 'Business not specified'}`
    : application.position;
  titleWrap.append(id, title, position);
  const status = document.createElement('span');
  status.className = 'status-pill';
  status.textContent = application.status;
  top.append(titleWrap, status);
  const details = document.createElement('div');
  details.className = 'result-details';
  details.append(detailCell('Submitted', formatDate(application.createdAt)), detailCell('Last updated', formatDate(application.updatedAt)));
  const reply = document.createElement('div');
  reply.className = 'reply-box';
  const label = document.createElement('small');
  label.textContent = 'REPLY FROM THE COMPANY';
  const message = document.createElement('p');
  message.textContent = application.reply || 'The company has not sent a reply yet. Please check again later.';
  reply.append(label, message);
  box.append(top, details, reply);
}
function detailCell(label, value) {
  const wrap = document.createElement('div');
  const small = document.createElement('span');
  small.textContent = label;
  const bold = document.createElement('b');
  bold.textContent = value || '—';
  wrap.append(small, bold);
  return wrap;
}
function formatDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '—' : date.toLocaleString();
}

$('#admin-login-form').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = $('button[type="submit"]', form);
  const notice = $('#login-message');
  clearNotice(notice);
  button.disabled = true;
  button.textContent = 'Verifying...';
  const password = new FormData(form).get('password');
  try {
    await api('/api/admin/login', { method: 'POST', body: JSON.stringify({ password }) });
    form.reset();
    showAdminDashboard();
    await loadApplications();
  } catch (error) {
    showNotice(notice, error.message);
  } finally {
    button.disabled = false;
    button.innerHTML = 'Unlock dashboard <span>→</span>';
  }
});

async function checkAdminSession() {
  try {
    const result = await api('/api/admin/me');
    if (result.isAdmin) {
      showAdminDashboard();
      await loadApplications();
    } else {
      showAdminLogin();
    }
  } catch {
    showAdminLogin();
  }
}
function showAdminLogin() {
  $('#admin-login-wrap').hidden = false;
  $('#admin-dashboard').hidden = true;
}
function showAdminDashboard() {
  $('#admin-login-wrap').hidden = true;
  $('#admin-dashboard').hidden = false;
}
$('#admin-logout').addEventListener('click', async () => {
  try {
    await api('/api/admin/logout', { method: 'POST', body: '{}' });
    cachedApplications = [];
    showAdminLogin();
    showToast('You have been logged out.');
  } catch (error) {
    showToast(error.message);
  }
});
$('#refresh-applications').addEventListener('click', loadApplications);
$('#application-search').addEventListener('input', renderApplications);
$$('[data-filter]').forEach(button => button.addEventListener('click', () => {
  activeFilter = button.dataset.filter;
  $$('[data-filter]').forEach(item => item.classList.toggle('active', item === button));
  renderApplications();
}));

async function loadApplications() {
  const list = $('#applications-list');
  list.innerHTML = '<div class="empty-state">Loading applications...</div>';
  try {
    const data = await api('/api/admin/applications');
    cachedApplications = data.applications;
    updateStats();
    renderApplications();
  } catch (error) {
    list.textContent = error.message;
  }
}
function updateStats() {
  const apps = cachedApplications;
  $('#application-count').textContent = apps.length;
  $('#stat-total').textContent = apps.length;
  $('#stat-new').textContent = apps.filter(item => ['Received', 'Under Review'].includes(item.status)).length;
  $('#stat-interview').textContent = apps.filter(item => ['Interview', 'Meeting'].includes(item.status)).length;
  $('#stat-accepted').textContent = apps.filter(item => item.status === 'Accepted').length;
}
function renderApplications() {
  const list = $('#applications-list');
  list.replaceChildren();
  const query = $('#application-search').value.trim().toLowerCase();
  const apps = cachedApplications.filter(item => {
    const matchesFilter = activeFilter === 'all' || (item.type || 'job') === activeFilter;
    const matchesQuery = [item.name, item.email, item.position, item.id, item.phone, item.businessName, item.dealType]
      .some(value => String(value || '').toLowerCase().includes(query));
    return matchesFilter && matchesQuery;
  });
  $('#admin-empty').hidden = apps.length !== 0;
  if (!apps.length) return;
  apps.forEach(application => list.append(createApplicationCard(application)));
}
function createApplicationCard(application) {
  const card = document.createElement('article');
  card.className = 'application-card';
  const summary = document.createElement('div');
  summary.className = 'application-summary';
  const info = document.createElement('div');
  const name = document.createElement('h4');
  name.className = 'applicant-name';
  name.textContent = application.name;
  const typeTag = document.createElement('span');
  typeTag.className = `submission-type ${application.type === 'business' ? 'business' : 'job'}`;
  typeTag.textContent = application.type === 'business' ? 'BUSINESS DEAL' : 'JOB APPLICATION';
  const meta = document.createElement('div');
  meta.className = 'application-meta';
  const primaryDetail = application.type === 'business'
    ? `${application.dealType || 'Business proposal'} · ${application.businessName || 'Business not specified'}`
    : application.position;
  [primaryDetail, application.email, application.phone, `ID: ${application.id}`].forEach(text => {
    const span = document.createElement('span');
    span.textContent = text;
    meta.append(span);
  });
  info.append(typeTag, name, meta);
  const right = document.createElement('div');
  right.className = 'summary-right';
  const date = document.createElement('span');
  date.className = 'date-label';
  date.textContent = formatDate(application.createdAt);
  const status = document.createElement('span');
  status.className = 'status-pill';
  status.textContent = application.status;
  const open = document.createElement('button');
  open.className = 'open-app';
  open.type = 'button';
  open.textContent = 'View & reply ↓';
  right.append(date, status, open);
  summary.append(info, right);

  const editor = document.createElement('form');
  editor.className = 'application-editor';
  editor.hidden = true;
  const personal = document.createElement('div');
  personal.className = 'field full';
  const messageLabel = document.createElement('span');
  messageLabel.textContent = application.type === 'business' ? 'Business proposal details' : 'Applicant message';
  const applicantMessage = document.createElement('textarea');
  applicantMessage.readOnly = true;
  applicantMessage.value = application.message;
  personal.append(messageLabel, applicantMessage);
  const experience = document.createElement('div');
  experience.className = 'field';
  const experienceLabel = document.createElement('span');
  experienceLabel.textContent = application.type === 'business' ? 'Business / company name' : 'Experience';
  const experienceValue = document.createElement('input');
  experienceValue.readOnly = true;
  experienceValue.value = application.type === 'business'
    ? (application.businessName || 'Not provided')
    : (application.experience || 'Not provided');
  experience.append(experienceLabel, experienceValue);
  const statusField = document.createElement('label');
  statusField.className = 'field';
  const statusLabel = document.createElement('span');
  statusLabel.textContent = application.type === 'business' ? 'Business deal status' : 'Application status';
  const select = document.createElement('select');
  select.name = 'status';
  const statusOptions = application.type === 'business' ? BUSINESS_STATUS_OPTIONS : JOB_STATUS_OPTIONS;
  statusOptions.forEach(option => {
    const opt = document.createElement('option');
    opt.value = option;
    opt.textContent = option;
    opt.selected = option === application.status;
    select.append(opt);
  });
  statusField.append(statusLabel, select);
  const replyField = document.createElement('label');
  replyField.className = 'field full';
  const replyLabel = document.createElement('span');
  replyLabel.textContent = 'Your reply to the applicant';
  const replyInput = document.createElement('textarea');
  replyInput.name = 'reply';
  replyInput.maxLength = 3000;
  replyInput.placeholder = application.type === 'business'
    ? 'Write a meeting invitation, negotiation update, or business proposal reply...'
    : 'Write an interview invitation, update, or other reply...';
  replyInput.value = application.reply || '';
  replyField.append(replyLabel, replyInput);
  const save = document.createElement('button');
  save.className = 'button button-primary';
  save.type = 'submit';
  save.textContent = 'Save status & reply →';
  const saveMessage = document.createElement('span');
  saveMessage.className = 'app-message';
  editor.append(personal, experience, statusField, replyField, save, saveMessage);
  open.addEventListener('click', () => {
    editor.hidden = !editor.hidden;
    open.textContent = editor.hidden ? 'View & reply ↓' : 'Close ↑';
  });
  editor.addEventListener('submit', async event => {
    event.preventDefault();
    save.disabled = true;
    save.textContent = 'Saving...';
    saveMessage.textContent = '';
    try {
      await api(`/api/admin/applications/${encodeURIComponent(application.id)}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: select.value, reply: replyInput.value })
      });
      application.status = select.value;
      application.reply = replyInput.value;
      application.updatedAt = new Date().toISOString();
      updateStats();
      status.textContent = application.status;
      saveMessage.textContent = 'Saved. The applicant can now see this update.';
      showToast('Submission updated successfully.');
    } catch (error) {
      saveMessage.textContent = error.message;
    } finally {
      save.disabled = false;
      save.textContent = 'Save status & reply →';
    }
  });
  card.append(summary, editor);
  return card;
}

$('#year').textContent = new Date().getFullYear();
const initialView = location.hash === '#track' ? 'track' : location.hash === '#admin' ? 'admin' : location.hash === '#business' ? 'business' : 'home';
if (initialView !== 'home') setView(initialView);
