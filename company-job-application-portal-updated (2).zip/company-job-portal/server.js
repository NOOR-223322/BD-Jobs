require('dotenv').config();

const express = require('express');
const session = require('express-session');
const SQLiteStoreFactory = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const helmet = require('helmet');
const { rateLimit } = require('express-rate-limit');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

if (IS_PRODUCTION && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error('Set SESSION_SECRET to a random value at least 32 characters long in production.');
}
if (IS_PRODUCTION && !process.env.ADMIN_PASSWORD) {
  throw new Error('Set a private ADMIN_PASSWORD in production.');
}

if (IS_PRODUCTION) app.set('trust proxy', 1);

const dataDir = path.dirname(process.env.DB_PATH || path.join(__dirname, 'data', 'applications.sqlite'));
fs.mkdirSync(dataDir, { recursive: true });
const dbPath = process.env.DB_PATH || path.join(dataDir, 'applications.sqlite');
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
  CREATE TABLE IF NOT EXISTS applications (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    position TEXT NOT NULL,
    experience TEXT DEFAULT '',
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Received',
    reply TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'job',
    business_name TEXT NOT NULL DEFAULT '',
    deal_type TEXT NOT NULL DEFAULT ''
  );
`);

// Add the new fields safely when upgrading an existing job-only database.
const existingColumns = new Set(db.prepare('PRAGMA table_info(applications)').all().map(column => column.name));
if (!existingColumns.has('type')) db.exec("ALTER TABLE applications ADD COLUMN type TEXT NOT NULL DEFAULT 'job'");
if (!existingColumns.has('business_name')) db.exec("ALTER TABLE applications ADD COLUMN business_name TEXT NOT NULL DEFAULT ''");
if (!existingColumns.has('deal_type')) db.exec("ALTER TABLE applications ADD COLUMN deal_type TEXT NOT NULL DEFAULT ''");

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", 'https://fonts.googleapis.com'],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", 'data:', 'https://fonts.gstatic.com'],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: IS_PRODUCTION ? [] : null
    }
  }
}));
app.use(express.json({ limit: '40kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

const sessionSecret = process.env.SESSION_SECRET || 'development-only-change-this-session-secret';
app.use(session({
  store: new SQLiteStoreFactory({ db: 'sessions.sqlite', dir: dataDir, table: 'sessions' }),
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  name: 'company_portal_session',
  cookie: {
    httpOnly: true,
    secure: IS_PRODUCTION,
    sameSite: 'strict',
    maxAge: 8 * 60 * 60 * 1000
  }
}));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many login attempts. Try again later.' } });
const applyLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many applications from this network. Please try later.' } });
const trackLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 25, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many tracking attempts. Please try later.' } });

function clean(value, maxLength) {
  return String(value ?? '').trim().slice(0, maxLength);
}
function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function isAdmin(req, res, next) {
  if (req.session && req.session.isAdmin === true) return next();
  return res.status(401).json({ error: 'Admin login required.' });
}
function safeApplication(row) {
  return {
    id: row.id,
    type: row.type || 'job',
    businessName: row.business_name || '',
    dealType: row.deal_type || '',
    name: row.name,
    email: row.email,
    phone: row.phone,
    position: row.position,
    experience: row.experience,
    message: row.message,
    status: row.status,
    reply: row.reply,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

app.post('/api/applications', applyLimiter, (req, res) => {
  const name = clean(req.body.name, 100);
  const email = clean(req.body.email, 160).toLowerCase();
  const phone = clean(req.body.phone, 40);
  const position = clean(req.body.position, 120);
  const experience = clean(req.body.experience, 100);
  const message = clean(req.body.message, 3000);

  if (name.length < 2 || !validEmail(email) || phone.length < 5 || position.length < 2 || message.length < 10) {
    return res.status(400).json({ error: 'Please complete all required fields with valid information.' });
  }

  const id = crypto.randomBytes(6).toString('hex').toUpperCase();
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO applications (id, name, email, phone, position, experience, message, created_at, updated_at, type)
    VALUES (@id, @name, @email, @phone, @position, @experience, @message, @now, @now, 'job')`)
    .run({ id, name, email, phone, position, experience, message, now });

  return res.status(201).json({ ok: true, id, type: 'job', message: 'Application submitted successfully.' });
});

app.post('/api/business-deals', applyLimiter, (req, res) => {
  const name = clean(req.body.name, 100);
  const email = clean(req.body.email, 160).toLowerCase();
  const phone = clean(req.body.phone, 40);
  const businessName = clean(req.body.businessName, 140);
  const dealType = clean(req.body.dealType, 80);
  const message = clean(req.body.message, 3000);
  const allowedDealTypes = ['Partnership', 'Investment', 'Supplier proposal', 'Distribution', 'Joint venture', 'Acquisition', 'Other'];

  if (name.length < 2 || !validEmail(email) || phone.length < 5 || businessName.length < 2 || !allowedDealTypes.includes(dealType) || message.length < 10) {
    return res.status(400).json({ error: 'Please complete all required business proposal fields with valid information.' });
  }

  const id = crypto.randomBytes(6).toString('hex').toUpperCase();
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO applications (id, name, email, phone, position, experience, message, created_at, updated_at, type, business_name, deal_type)
    VALUES (@id, @name, @email, @phone, @dealType, '', @message, @now, @now, 'business', @businessName, @dealType)`)
    .run({ id, name, email, phone, businessName, dealType, message, now });

  return res.status(201).json({ ok: true, id, type: 'business', message: 'Business proposal submitted successfully.' });
});

app.post('/api/track', trackLimiter, (req, res) => {
  const id = clean(req.body.id, 20).toUpperCase();
  const email = clean(req.body.email, 160).toLowerCase();
  if (!id || !validEmail(email)) return res.status(400).json({ error: 'Enter your Submission ID and the email used to submit.' });

  const row = db.prepare('SELECT id, name, position, status, reply, created_at, updated_at, type, business_name, deal_type FROM applications WHERE id = ? AND email = ?')
    .get(id, email);
  if (!row) return res.status(404).json({ error: 'No submission found. Check your Submission ID and email.' });
  return res.json({
    application: {
      id: row.id,
      type: row.type || 'job',
      businessName: row.business_name || '',
      dealType: row.deal_type || '',
      name: row.name,
      position: row.position,
      status: row.status,
      reply: row.reply,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    }
  });
});

app.post('/api/admin/login', loginLimiter, (req, res, next) => {
  const supplied = Buffer.from(clean(req.body.password, 200));
  const expected = Buffer.from(process.env.ADMIN_PASSWORD || '223311');
  const matches = supplied.length === expected.length && crypto.timingSafeEqual(supplied, expected);
  if (!matches) return res.status(401).json({ error: 'Incorrect admin password.' });

  req.session.regenerate((err) => {
    if (err) return next(err);
    req.session.isAdmin = true;
    req.session.save((saveErr) => {
      if (saveErr) return next(saveErr);
      return res.json({ ok: true });
    });
  });
});

app.get('/api/admin/me', (req, res) => {
  res.json({ isAdmin: req.session?.isAdmin === true });
});

app.post('/api/admin/logout', isAdmin, (req, res, next) => {
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('company_portal_session', { httpOnly: true, sameSite: 'strict', secure: IS_PRODUCTION });
    return res.json({ ok: true });
  });
});

app.get('/api/admin/applications', isAdmin, (req, res) => {
  const rows = db.prepare('SELECT * FROM applications ORDER BY created_at DESC').all();
  return res.json({ applications: rows.map(safeApplication) });
});

app.patch('/api/admin/applications/:id', isAdmin, (req, res) => {
  const id = clean(req.params.id, 20).toUpperCase();
  const status = clean(req.body.status, 30);
  const reply = clean(req.body.reply, 3000);
  const row = db.prepare('SELECT type FROM applications WHERE id = ?').get(id);
  if (!row) return res.status(404).json({ error: 'Application not found.' });
  const allowed = row.type === 'business'
    ? ['Received', 'Under Review', 'Meeting', 'Negotiating', 'Accepted', 'Rejected']
    : ['Received', 'Under Review', 'Shortlisted', 'Interview', 'Accepted', 'Rejected'];
  
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Choose a valid application status.' });

  const result = db.prepare('UPDATE applications SET status = ?, reply = ?, updated_at = ? WHERE id = ?')
    .run(status, reply, new Date().toISOString(), id);
  if (result.changes === 0) return res.status(404).json({ error: 'Application not found.' });
  return res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  return res.status(500).json({ error: 'Server error. Please try again.' });
});

app.listen(PORT, () => {
  console.log(`Company Job Portal running at http://localhost:${PORT}`);
});
